# youtube_live_status

### how to download
`pip install youtube-lv`

### how to use

```python
from ytlv import *
live=islive("channel ID")
print(live)
```
