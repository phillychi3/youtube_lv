# youtube_live_status

###how to use
```python
from ytlive import islive
live=islive("channel ID")
```
