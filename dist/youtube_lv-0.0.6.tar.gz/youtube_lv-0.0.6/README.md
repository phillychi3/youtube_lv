# youtube_live_status

### how to download
`pip install youtube-live-status`

### how to use

```python
from youtube_live_status import *
live=islive("channel ID")
```
